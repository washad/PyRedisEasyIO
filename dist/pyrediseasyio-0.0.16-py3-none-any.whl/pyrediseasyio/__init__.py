from pyrediseasyio.io.io_group import IOGroup
from pyrediseasyio.html.html_io_group import HMTLIOGroup
from pyrediseasyio.html.html_io import HTMLIO
from pyrediseasyio.io.base import SingleIO
from pyrediseasyio.io.boolean_io import BooleanIO
from pyrediseasyio.io.string_io import StringIO
from pyrediseasyio.io.float_io import FloatIO
from pyrediseasyio.io.integer_io import IntIO
